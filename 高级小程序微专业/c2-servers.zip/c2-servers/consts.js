module.exports = {
	// 商户号
	MCHID: 1489624802,
	// 商户秘钥
	MCHKEY: '',
	// APPID
	APPID: '',
	// 小程序secret
	SECRET: ''
};